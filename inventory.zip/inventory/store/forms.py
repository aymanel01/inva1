from django import forms

from .models import Season, Drop, Product, Order, Delivery


class SupplierForm(forms.Form):
    name = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'form-control',
        'id': 'name',
        'data-val': 'true',
        'data-val-required': 'Please enter name',
    }))
    address = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'form-control',
        'id': 'address',
        'data-val': 'true',
        'data-val-required': 'Please enter address',
    }))

class BuyerForm(forms.Form):
    name = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'form-control',
        'id': 'name',
        'data-val': 'true',
        'data-val-required': 'Please enter name',
    }))
    address = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'form-control',
        'id': 'address',
        'data-val': 'true',
        'data-val-required': 'Please enter address',
    }))


class DropForm(forms.ModelForm):
    class Meta:
        model = Drop
        fields = ['name']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'id': 'name'})
        }



class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name','code', 'sortno','price']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'id': 'name'}),
            'code': forms.TextInput(attrs={'class': 'form-control', 'id': 'code'}),
            'sortno': forms.NumberInput(attrs={'class': 'form-control', 'id': 'sortno'}),
            'price': forms.NumberInput(attrs={'class': 'form-control', 'id': 'price'})
        }


class OrderForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['supplier','code', 'product', 'price', 'sortno']

        widgets = {
            'supplier': forms.TextInput(attrs={'class': 'form-control', 'id': 'supplier_name'}),
            'product': forms.TextInput(attrs={'class': 'form-control', 'id': 'product'}),
            'code': forms.TextInput(attrs={'class': 'form-control', 'id': 'code'}),
            'price': forms.NumberInput(attrs={'class': 'form-control', 'id': 'price'}),
            'sortno': forms.NumberInput(attrs={'class': 'form-control', 'id': 'sortno'}),
        }


class DeliveryForm(forms.ModelForm):
    class Meta:
        model = Delivery
        fields = '__all__'

        widgets = {
            'order': forms.Select(attrs={'class': 'form-control', 'id': 'order'}),
            'courier_name': forms.TextInput(attrs={'class': 'form-control', 'id': 'courier_name'}),
        }

class SeasonForm(forms.ModelForm):
    class Meta:
        model = Season
        fields = ['Buyer', 'product','code', 'price', 'sortno']

        widgets = {
            'Buyer': forms.TextInput(attrs={'class': 'form-control', 'id': 'Buyer'}),
            'product': forms.TextInput(attrs={'class': 'form-control', 'id': 'product'}),
            'code': forms.TextInput(attrs={'class': 'form-control', 'id': 'code'}),
            'price': forms.NumberInput(attrs={'class': 'form-control', 'id': 'price'}),
            'sortno': forms.NumberInput(attrs={'class': 'form-control', 'id': 'sortno'}),
        }
